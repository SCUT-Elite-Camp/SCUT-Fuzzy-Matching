"""MinHash encoding package."""

