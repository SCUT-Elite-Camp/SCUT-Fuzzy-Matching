
# 任务5：实验与对比 —— 基线模型汇报（最终版）

## 一、任务定位：实验模块在整个协议中的角色

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  任务1      │     │  任务2      │     │  任务3/4    │
│  MinHash    │────▶│  CKKS加密   │────▶│  匹配协议   │
│  姓名编码   │     │  密钥管理   │     │  聚类/列匹配 │
└─────────────┘     └─────────────┘     └─────────────┘
│
▼
┌─────────────┐
│  任务5      │
│  实验与对比 │
└─────────────┘
│
▼
┌─────────────┐
│  结果报告   │
│  精度/性能  │
└─────────────┘
```


**我负责最下游的验证环节**：接收所有模块的输出，进行指标计算和性能分析，输出面向论文和团队的实验报告。


## 二、数据流详解（上游 → 我的模块 → 下游）

### 2.1 上游接收什么数据？

| 来源模块 | 数据类型 | 具体内容 | 用途 |
|---------|---------|---------|------|
| 任务1 (MinHash) | 签名矩阵 | names_A, names_B 的归一化签名（EL=200/50） | 模拟查询和数据库 |
| 任务2 (CKKS) | 密文对象 | 加密查询向量 E(N̂_As_200), E(N̂_A_50), E(S) | 测量通信开销 |
| 任务3/4 (协议) | 匹配结果 | 每列加密分数 E(score_j)，解密后的 catch 值 | 计算精确率/召回率 |
| 原始数据集文件 | CSV/文本 | NCVR、图书馆目录、US Census 文件 | 构建 ground truth 标签 |
| 协议计时数据 | 时间戳 | 离线预处理时间、每轮在线时间 | 性能分析 |

### 2.2 向下游提供什么数据？

| 输出内容 | 格式 | 消费者 |
|---------|------|--------|
| 精度指标 | dict (precision, recall, f1, accuracy) | 组长、论文、团队报告 |
| 通信开销表 | dict (sent_bytes, recv_bytes, total_mb) | 组长、论文、团队报告 |
| 时间/内存测量 | dict (offline_sec, online_sec, memory_peak_mb) | 性能优化依据 |
| 消融实验结果 | CSV / JSON 文件 | 后续对比分析、图表绘制 |
| 与 baseline 对比 | 表格 (本方案 vs SFour/SPRL/AHE) | 证明方案优势 |


## 三、对外暴露的接口设计（符合规范）

| 接口 | 输入 | 输出 | 实现状态 | 上游数据来源 | 下游消费者 |
|------|------|------|----------|--------------|------------|
| dataset_loader(name, path) | 数据集名称 + 文件路径 | (names_A, names_B, labels) | ✅ 已完成 | 原始 CSV 文件 | benchmark 函数 |
| metrics(preds, labels) | 预测布尔列表 + 真实布尔列表 | {precision, recall, f1, accuracy} | ✅ 已完成 | 协议输出的 catch 值 | 结果报告 |
| communication_cost(ct) | TenSEAL 密文对象 | int (字节数) | ✅ 已完成 | 任务2 加密输出 | 通信开销表 |
| benchmark(config) | 配置字典 (见下方示例) | 完整性能指标字典 | ✅ 已完成 (mock 模式) | 所有上游模块 | 最终报告 |

**config 字典示例**：
```python
config = {
    "dataset": "ncvr",
    "data_path": "./data/",
    "el_cluster": 200,
    "el_match": 50,
    "k": 50,
    "tau": 0.9,
    "query_limit": 20,
    "use_mock": True
}
```


四、思路与设计要点

1. 解耦与模拟优先
   · 设计 use_mock 开关，即使其他模块未就绪，也能验证实验流程的正确性。
   · mock 数据生成器模拟 MinHash 签名、聚类矩阵、质心等，确保接口形状匹配。
2. 关注金融场景的特殊需求
   · 精确率优先于召回率（误报成本高）。
   · 实验设计需体现 trade-off：聚类带来的效率提升 vs 召回率下降。
3. 可复现性
   · 所有随机过程固定种子 (RANDOM_SEED = 42)。
   · 每个参数组合重复 3~5 次，输出均值和标准差。
4. 性能测量的全面性
   · 时间：区分离线/在线、第一轮/第二轮、early stop 时间。
   · 通信：使用 TenSEAL 的 serialize() 精确测量字节。
   · 内存：使用 tracemalloc 记录峰值。
5. 消融实验覆盖关键变量
   · 编码长度 EL (50, 100, 200)
   · 聚类数 k (0, √N, 2√N)
   · 阈值 τ (0.5~0.95)
   · 数据规模 (1k, 10k, 100k)


五、当前运行结果（mock 模式验证）

```text
=== Testing dataset loader ===
Loaded 100 queries, 1000 DB entries, 10 matches

=== Testing metrics ===
{'precision': 0.67, 'recall': 0.67, 'f1': 0.67, 'accuracy': 0.6}

=== Testing ciphertext size measurement ===
Mock ciphertext size: 1024 bytes

=== Running benchmark (mock mode) ===
Benchmark result:
  metrics: {'precision': 0.5, 'recall': 1.0, 'f1': 0.67, 'accuracy': 0.5}
  timing_sec: offline=0.0107s, online_total=0.0009s
  communication_mb: sent=0.009MB, recv=0.108MB, total=0.117MB
  memory_peak_mb: 11.52MB
```

注：mock 模式仅验证流程，真实性能数据需集成真实模块后重新测量。


六、与其他模块的对接计划

| 依赖模块 | 所需接口/数据 | 当前状态 | 集成计划 |
|---------|---------------|----------|----------|
| 任务1 | (MinHash) batch_encode(names, el) -> ndarray | 未就绪 | 等接口稳定后替换 mock |
| 任务2 | (CKKS) encrypt(vec), decrypt(ct), 序列化 | 未就绪 | 等接口稳定后替换 mock |
| 任务3 | (加密余弦) dot_ct_pt, dot_ct_ct, subtract_threshold | 未就绪 | 等接口稳定后替换 mock |
| 任务4 (聚类) | run_kmeans, build_column_matrix, compare_to_centroids | 未就绪 | 等接口稳定后替换 mock |


我的代码已预留切换点：在 benchmark.py 中，当 use_mock=False 时，将调用真实模块的函数。一旦其他模块提供接口，只需修改少量代码即可集成。

七、下一步工作

1. 等待其他模块交付 → 替换 mock 为真实调用。
2. 运行完整消融实验 → 生成精度-效率曲线。
3. 与 baseline 对比 → 引用论文数据或复现关键指标。
4. 输出 Baseline 报告 → 包含图表、瓶颈分析、优化建议。

八、问题与风险提示

· CKKS 噪声：乘法深度有限，需验证 max_size 较大时噪声是否会淹没阈值判断。
· 数据依赖：真实数据集需要清洗和 ground truth 构建，目前 mock 数据仅用于流程测试。
· 性能瓶颈：聚类数 k 和最大簇大小 max_size 直接影响在线时间，需实验确定最优 k。